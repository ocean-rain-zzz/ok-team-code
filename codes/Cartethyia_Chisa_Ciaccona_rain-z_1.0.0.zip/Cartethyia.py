import time, cv2
import numpy as np
from src.char.BaseChar import BaseChar, SwitchPriority, forte_white_color


class Cartethyia(BaseChar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.is_cartethyia = True
        self.buffs = {'sword1': None, 'sword2': None, 'sword3': None}
        self.template_shape = None
        self.try_mid_air_attack_once = False
        self.transform = False
        self.res_time = -1
        self.n4_time = -1
        self.init_template()

    @property
    def intro_motion_freeze_duration(self):
        return 0.6 if self.is_cartethyia else 0.78

    @intro_motion_freeze_duration.setter
    def intro_motion_freeze_duration(self, _):
        pass

    def init_template(self):
        self.template_shape = self.task.frame.shape[:2]
        template = self.task.get_feature_by_name('forte_cartethyia_sword3')
        original_mat = template.mat
        h = original_mat.shape[0]
        self.sword3_half_mat = original_mat[:int(h * 0.5)]
        target_box = self.task.get_box_by_name('forte_cartethyia_sword3')
        target_box.height = int(h * 0.6)
        self.sword3_half_box = target_box

    def on_combat_end(self, chars):
        
        self.logger.debug(f'on_combat_end {self.index} switch end')

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if not self.is_cartethyia:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
        
        
    # 下面各自的常量写在这一段【之后】, 所以子类想覆盖哪个直接在下面重写就行。
    #
    # 为什么不用框架的 switch_next_char():
    #   1. 它按 get_switch_priority() 现场挑人, 顺序会漂 —— 这套轴要求死顺序;
    #   2. 它内部有三处补普攻 ("performing too fast add a normal attack"、维持锁定、
    #      切换未检测到时补点击), 打完最后一下想立刻走人时那几下 A 会把节奏拖乱。
    # 代价是框架的交接记账要自己补, 全在 handoff_to() 里。

    SWITCH_TIMEOUT: float = 2.0        # 单程切人的最长尝试时间 (秒)
    SWITCH_KEY_INTERVAL: float = 0.12  # 连按数字键的间隔 (秒)
    # 切到之后等角色站稳的时间 (秒)。很敏感 —— 实测 0.50 / 0.52 会让下一个角色的起手被吞,
    # 0.55 才稳, 别再往下压
    SWITCH_SETTLE: float = 0.55
    SETTLE_ATTACK_INTERVAL: float = 0.42
    HANDOFF_CON_WAIT: float = 0.8      # 交接时等协奏读数稳定的上限 (秒)
    HANDOFF_CON_POLL: float = 0.1
    HOLD_POLL: float = 0.1             # 长按期间轮询条件的间隔 (秒)
    # 切走前按 F 处决 —— 框架 switch_next_char() 里有 current_char.f_break(True), 直接
    # 按数字键切人会绕开它。这套轴里默认【关掉】: handoff_to() 是在 switch_to_index()
    # 之后调的, 那时候下一个角色已经站上场了, 这一下 F 会被他吃掉, 而且发生在他的 R
    # 之前 (千咲"还没按 R 就开处决"就是这么来的)。处决统一由千咲在 R 之后接
    F_BREAK_ON_HANDOFF: bool = False

    # 别人用 handoff_to() 直接切给我时打的标记, 写成类属性省掉 __init__。
    # 不能只靠 has_intro —— reset_state() 每次重读队伍都会把它清成 False, 而战斗判定
    # 一抖动就会重进战斗、重读队伍, 于是角色以为自己空手入场, 跑去走开场那套流程
    intro_pending = False
    # 切人【真正完成】那一刻的时间戳 —— in_team 认出换人成功的那一帧, 不是
    # settle_with_attack 站稳之后。循环轴的落地E 就按这个锚点计时, 差 0.55 秒
    # 就会掉进"E 按在下落段完全没反应"的失败区
    switch_confirmed_at = 0.0
    E_LIT_BOX: str = 'box_liberation'
    E_LIT_COLOR = {'r': (200, 255), 'g': (200, 255), 'b': (200, 255)}
    # 0.13, 跟秧秧同一个值。千咲实测亮起时 0.1619, 落在秧秧标定的亮起区间 0.158~0.211 内
    E_LIT_THRESHOLD: float = 0.3
    E_LIT_CONFIRM: int = 2         # 连续这么多次过阈值才认, 挡单点噪声
    E_LIT_POLL: float = 0.05       # 轮询间隔 (秒)
    E_LIT_MAX_WAIT: float = 6    # 等图标亮的上限 (秒), 到点没亮也照按
    # 采样打日志。已标定完关掉 —— 00:23 实测 R 结束那一刻 white=0.1619 就已经过阈,
    # 0.07s 按下强化E。要重新标定 (换角色/换界面) 再打开
    E_LIT_PROBE: bool = False
    E_LIT_PROBE_INTERVAL: float = 0.15
    GAP_ATTACK_INTERVAL: float = 0.22
    CON_CONFIRM: int = 3
    
    
    
    
    #卡夏千5r9下落文字轴
    #启动轴：小卡er大卡ee  夏空aeqr 千ea 大卡a 千a 大卡ar 小卡4az跳a 千qr 大卡aar
    # 变奏夏空aa跳ze 变奏千e 开始锯切 变奏小卡跳a
    
    #定义启动轴与循环轴的标记
    start_loop = 0
    #当前轴的节点
    axis_node = 1
    #首轮轴的标记
    first_loop = 0
    #次轮轴的标记
    second_loop = 0
    #尾轮轴的标记
    last_loop = 1
    
    def do_perform(self):
        #如果是启动轴
        self.logger.info(f'卡提启动,当前节点{self.axis_node}')
        
        if self.start_loop == 0:
            #判断当前节点
            if self.axis_node == 1:
                #小卡er大卡ee
                self.click_resonance(send_click=False,post_sleep=0.2)
                self.click_liberation(wait_if_cd_ready=0.3,send_click=False)  # R
                self.click_resonance(send_click=False,click_f=False)
                self.send_resonance_key()
                #切夏空
                self.axis_node = 2
                self.direct_switch(slot=2, assume_intro=False)
                #self.macro_wait(self.O_QING_JUMP_SETTLE)
                return
            if self.axis_node == 4:
                #大卡a到举剑
                self.continues_normal_attack(1)
                self.axis_node = 5
                #切千a
                self.direct_switch(slot=3,assume_intro=False)
                return
            if self.axis_node == 6:
                #大卡a到大剑下落，r变小卡4aZ跳a 变大卡切千
                #self.logger.info(f'卡提进入节点{self.axis_node}')
                self.continues_normal_attack(0.3)
                
                #变小卡
                self.send_liberation_key()
                self.continues_normal_attack(1.3)
                #self.continues_normal_attack(0.3)
                #切千xiao
                self.axis_node = 7
                self.direct_switch(slot=3,assume_intro=False)
                return
            if self.axis_node == 8:
                #大卡aar
                
                #中间插入声骸防肘
                
                #self.continues_normal_attack(1.8)
                self.heavy_attack(1.2)
                self.task.jump(after_sleep=0.02)
                self.continues_normal_attack(0.7)
                #变大卡
                self.send_liberation_key()
                self.continues_normal_attack(1)
                self.click_echo()
                self.continues_normal_attack(1.7)
                #等待大招亮起
                self.wait_r_lit()
                self.click_liberation()
                #变奏夏空
                #必须协奏满变奏夏空，否则轴全乱
                self.must_con_full()
                self.axis_node = 9
                self.direct_switch(slot=2,assume_intro=True)
                return
            if self.axis_node == 11:
                #锯切，卡提a到矩形出现，切千
                self.continues_normal_attack(0.2)
                self.axis_node = 12
                self.direct_switch(slot=3,assume_intro=False)
                return
            if self.axis_node == 13:
                #卡提a到剑下落，切千
                self.continues_normal_attack(1.05)
                self.axis_node = 14
                self.direct_switch(slot=3,assume_intro=False)
                return
            if self.axis_node == 15:
                #卡提变奏入场跳a，启动轴结束，开始循环
                #等待变奏动画打完
                self.sleep(1)
                if self.last_loop < 4:
                    self.task.jump(after_sleep=0.02)
                    self.continues_normal_attack(1)
                else:
                    self.click_resonance(send_click=True)
                    self.continues_normal_attack(1.3)
                ##新增，切夏空下落偷一个回路
                #self.axis_node = 16
                #self.direct_switch(slot=2, assume_intro=False)
                #return
                #if self.axis_node == 17:
                #小卡er大卡ee
                if self.last_loop < 4:
                    self.click_resonance(send_click=False,post_sleep=0.2)
                self.click_liberation(wait_if_cd_ready=0.3,send_click=True)  # R
                self.click_resonance(send_click=False,click_f=False)
                self.send_resonance_key()
                #切夏空
                self.axis_node = 2
                self.second_loop = 1
                self.first_loop = 1
                self.last_loop = self.last_loop + 1
                self.direct_switch(slot=2, assume_intro=False)
                return
            if self.axis_node == 20:
                #尾轮
                #大卡a到大剑下落，一直普攻到能量满
                #self.logger.info(f'卡提进入节点{self.axis_node}')
                self.continues_normal_attack(1.3)
                self.heavy_attack(0.8)
                self.continues_normal_attack(2)
                self.wait_r_lit()
                self.click_liberation()
                return
        self.continues_normal_attack(3)
        self.direct_switch(slot=3,assume_intro=False)                

    def macro_wait(self, sec):
        """精确等待, 【不点击】。

        不走 executor.sleep —— 它每 0.4 秒无条件插一次 next_frame 截图, 插入位置
        不可控, 而这条轴的容错在 ±0.1 秒级。切成 0.1 秒一片, 片间检查任务是否被停用。
        """
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)
            
    def direct_switch(self, slot=None, assume_intro=False):
        """按数字键直接切到指定队伍位置 (1-based), 并自己补上框架的交接记账。

        Args:
            slot: 不传就用 NEXT_SLOT。
            assume_intro: True 时不读协奏, 直接认定是满的。刚放完大招要用这个 ——
                能量环读数滞后会把 has_intro 误判成 False, 下一个角色就拿不到变奏增益。
        """
   
        if slot is None:
            return False
        target = self.char_at_slot(slot)
        if target is None or target is self:
            return False

        has_intro = assume_intro
        if not self.switch_to_slot(slot):
            self.logger.warning(f'direct switch to slot {slot} failed')
            return False
        self.logger.info(f'direct switched to slot {slot} ({target.char_name}, intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True
        
    def switch_to_slot(self, slot):
        """按数字键切到指定队伍位置, 直到 in_team 确认切过去了。

        点击落在谁身上就由谁打出来, 所以等待期间也保持点普攻, 两边连段都不断档。
        """
        start = time.time()
        index = slot - 1
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                # 【先记时间戳再站稳】: settle_with_attack 要花 SWITCH_SETTLE 秒,
                # 记在它后面的话锚点整体晚 0.55 秒, 靠锚点计时的动作全跟着晚
                self.switch_confirmed_at = time.time()
                #self.settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(slot)
            self.click()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)
        return False
        
    def handoff_to(self, target, has_intro):
        """把场上角色交接给 target —— 复刻 switch_next_char() 内部那套记账。

        直接按数字键切人绕开了框架的交接逻辑, 必须自己补上, 否则:
          - 没人的 is_current_char 是 True → get_current_char() 返回 None → 下一帧崩溃;
          - has_intro / last_outro_time 不更新, 下一个角色拿不到变奏。
        """
        self.task.in_liberation = False
        super().switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            # has_intro 是易失的, 再给对方补一个它自己保管的持久标记
            target.note_intro_handoff()
        # 用 in_team 确认那一刻, 不是现在 —— 中间隔着 settle_with_attack 那 0.55 秒
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def settle_with_attack(self, duration):
        """等 duration 秒, 期间保持点普攻, 不干等。"""
        end = time.time() + duration
        while time.time() < end:
            self.click()
            self.sleep(min(self.SETTLE_ATTACK_INTERVAL, max(0.0, end - time.time())),
                       check_combat=False)
 
    def char_at_slot(self, slot):
        """按队伍位置 (1-based) 取角色, 越界返回 None。"""
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def must_liberation(self):
        #必须有大才能继续流程，没大一直普攻到有大
        start = time.time()
        hits = 0
        last_click = -1.0
        last_probe = -1.0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= self.E_LIT_MAX_WAIT:
                self.logger.info(f'cartethyia: e icon not lit in {self.E_LIT_MAX_WAIT:.1f}s, '
                                 f'pressing anyway')
                return elapsed

            if elapsed - last_click >= self.GAP_ATTACK_INTERVAL:
                last_click = elapsed
                self.click()

            if self.liberation_available():
                return
            self.sleep(self.E_LIT_POLL)

    def must_con_full(self):
        #必须协奏满才能继续流程，没大一直普攻到满
        start = time.time()
        hits = 0
        last_click = -1.0
        last_probe = -1.0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= self.E_LIT_MAX_WAIT:
                self.logger.info(f'cartethyia: e icon not lit in {self.E_LIT_MAX_WAIT:.1f}s, '
                                 f'pressing anyway')
                return elapsed

            if elapsed - last_click >= self.GAP_ATTACK_INTERVAL:
                last_click = elapsed
                self.click()
            #self.logger.info(f'cartethyia 协奏未满')
            if self.con_full_confirmed():
                return
            #self.logger.info(f'cartethyia 协奏未满 用时{elapsed}')
            self.sleep(self.E_LIT_POLL)

    def con_full_confirmed(self):
        """协奏满不满 —— 连读 CON_CONFIRM 帧都满才认。

        绕开 BaseChar.is_con_full() 的缓存 (`if self.current_con == 1: return True`)
        直接问 task: 那个缓存一旦被写成 1 就粘住不放, 只有"满协奏离场"才会清零,
        用它做 gate 等于把误判永久化。
        """
        for i in range(self.CON_CONFIRM):
            if not self.task.is_con_full():
                return False
            if i + 1 < self.CON_CONFIRM:
                self.task.next_frame()  # 换一帧再读, 否则读的是同一张图
        return True
  
       
    def wait_r_lit(self):
        """等 E 图标变成强化高亮。期间保持点普攻, 不干等。

        返回等了多久 (秒)。超时也返回, 由调用方照样按 —— 识别失灵不该把轴卡死。
        """
        start = time.time()
        hits = 0
        last_click = -1.0
        last_probe = -1.0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= self.E_LIT_MAX_WAIT:
                self.logger.info(f'cartethyia: e icon not lit in {self.E_LIT_MAX_WAIT:.1f}s, '
                                 f'pressing anyway')
                return elapsed

            if elapsed - last_click >= self.GAP_ATTACK_INTERVAL:
                last_click = elapsed
                self.click()

            white = self.r_icon_white()
            self.logger.info(f'cartethyia probe t={elapsed:.2f}s white={white:.4f}')
            if self.E_LIT_PROBE and elapsed - last_probe >= self.E_LIT_PROBE_INTERVAL:
                last_probe = elapsed
                self.logger.info(f'cartethyia probe t={elapsed:.2f}s white={white:.4f}')

            hits = hits + 1 if white >= self.E_LIT_THRESHOLD else 0
            if hits >= self.E_LIT_CONFIRM:
                return elapsed
            self.sleep(self.E_LIT_POLL)

    def r_icon_white(self):
        """E 技能图标框里的白像素占比。读不到时返回 -1, 不让它把轴卡住。"""
        try:
            box = self.task.get_box_by_name(self.E_LIT_BOX)
            return self.task.calculate_color_percentage(self.E_LIT_COLOR, box)
        except Exception as e:
            self.logger.info(f'cartethyia: e icon probe failed ({e})')
            return -1
